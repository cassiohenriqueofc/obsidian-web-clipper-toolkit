# Change log

## 0.1.5 — SEO playbook and proposal guide

- Add an Obsidian-ready SEO and indexing playbook with current status, locale metadata, platform preview mockups, Mermaid diagrams, sources, and a reusable proposal checklist.
- Link the playbook from the README, SEO review, generated LLM guide, and site file map.

## 0.1.4 — SEO metadata and handoff

- Add a 1200 × 630 social image for generated Open Graph and Twitter previews.
- Add canonical URLs, seven-language alternates, x-default, image dimensions, and accessibility metadata to indexable pages.
- Add a noindex language chooser and a noindex 404 page; publish a sitemap with the Proposal date as lastmod.
- Document indexing limits and create a dated handoff; no deployment or search indexing is claimed.
- Add an Obsidian-ready SEO playbook with current locale metadata, platform preview mockups, indexing status, diagrams, and a proposal checklist.


## 0.1.3 — Public site configuration

- Configure a GitHub Pages deployment workflow with canonical, indexable metadata and sitemap; deployment awaits resolution of the GitHub account billing lock.
- Update public project status, landing-page URL, and publication instructions across seven locales.
- Preserve the static social-preview image and the separate animated feature flow.


## 0.1.2 — 2026-11-18

- Add an animated five-stage feature flow based on the existing social-preview image.
- Add a reduced-motion static fallback and pause/resume control to the multilingual site.
- Refresh the English README introduction with navigation, accurate feature badges, and the animation.
- Keep the existing static banner and OpenGraph image.

## 0.1.1 — 2026-11-18

- Rename the repository to `obsidian-web-clipper-toolkit` and update repository links.
- Reshape the English README around the toolkit, templates, quick start, and review limits.
- Add clear language navigation and section links to localized README files.
- Improve static-site descriptions and social metadata while preserving default noindex.
- Record current SEO guidance, GitHub discovery constraints, and publication steps.

## 0.1.0 — 2026-11-18

- Package three general Web Clipper templates with demo-only vault configuration.
- Add documentation and navigation for en-US, pt-BR, es-AR, es-MX, es-ES, de-DE and fr-FR.
- Add a Proposal-driven reusable project/file starter and project-only local-clone/private-remote memory rules.
- Include only explicitly approved public attribution; other personal data remains excluded.
- Add an original generated banner and animated, linked documentation/file map.
- Add local customization, validation, packaging, checksums, and a read-only CI workflow.
- Document baseline 1.7.1 renderer checks and unperformed live compatibility checks.
- Adopt the custom noncommercial source-available license selected by the owner.
- Restrict scaffold output to reviewed public proposal fields and approved attribution; derive language metadata from delivered READMEs.
- Exclude original settings exports, personal paths, credentials, and private notes.

No automatic second-vault copy, public deployment, or specialist design-system
template is included in this release.
